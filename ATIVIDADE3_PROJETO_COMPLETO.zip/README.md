# 📊 Atividade 3 - IA no Setor Bancário

README de exemplo.